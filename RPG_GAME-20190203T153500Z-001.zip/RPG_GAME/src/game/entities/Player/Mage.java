package game.entities.Player;

import java.awt.Graphics;

import game.characters.Spell;
import game.gfx.Assets;
import game.run.Game;
import game.run.Handler;

public class Mage extends Player{
	private int mana=400;
	private Spell[] spells;
	private Game game;
	//private Weapon[] weapons;
	//private Potions[] potions;
	
	public Mage(Handler handler, float x, float y) { 
		super(handler, x, y, Player.DEFAULT_WIDTH, Player.DEFAULT_HEIGHT);
		bounds.x =20;
		bounds.y =18;
		bounds.width = 48;
		bounds.height =48;
		
		setLvl(1);
		setMaxHealth(200);
		setCurrentHealth(getMaxHealth());
		setXP(0);
		setAD(20);
		setSpells(spells);
		
	}
	public void setSpells(Spell[] spells) {
		this.spells=spells;
	}
	public Spell[] getSpells() {
		return spells;
	}
	
	private void getInput() {
		xMove = 0;
		yMove = 0;
		if(handler.getKeyManager().up) {
			yMove = -speed;
		}
		if(handler.getKeyManager().down) {
			yMove = speed;
		}
		if(handler.getKeyManager().left) {
			xMove = -speed;
		}
		if(handler.getKeyManager().right) {
			xMove = speed;
		}
	}
	
	@Override
	public void tick() {
		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this);
		
	}
	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.mage, (int)(x - handler.getGameCamera().getxOffset()), 
				(int)(y - handler.getGameCamera().getyOffset()), width, height, null);
		
	}
	
	
	


}
