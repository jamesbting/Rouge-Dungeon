package game.entities.Player;

import java.awt.Color;
import java.awt.Graphics;

import game.characters.Attacks;
import game.gfx.Assets;
import game.run.Game;
import game.run.Handler;

public class Knight extends Player{
	
	//private weapon starterWeapon=dagger;
	private Attacks[] attacks;
	
	public Knight(Handler handler, float x, float y) {
		super(handler, x,y, Player.DEFAULT_WIDTH, Player.DEFAULT_HEIGHT);
		bounds.x =23;
		bounds.y =10;
		bounds.width = 48;
		bounds.height =54;
		
		setLvl(1);
		setMaxHealth(300);
		setCurrentHealth(getMaxHealth());
		setXP(0);
		setAD(30);
		setAttacks(attacks);
	}
	public Attacks[] getAttacks() {
		return this.attacks;
	}
	public void setAttacks(Attacks[] attacks) {
		this.attacks=attacks;
	}
	
	private void getInput() {
		xMove = 0;
		yMove = 0;
		if(handler.getKeyManager().up) {
			yMove = -speed;
		}
		if(handler.getKeyManager().down) {
			yMove = speed;
		}
		if(handler.getKeyManager().left) {
			xMove = -speed;
		}
		if(handler.getKeyManager().right) {
			xMove = speed;
		}
	}

	@Override
	public void tick() {
		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this);
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.knight, (int)(x - handler.getGameCamera().getxOffset()), 
				(int)(y - handler.getGameCamera().getyOffset()), width, height, null);
		
		//g.setColor(Color.red);
		//g.fillRect((int) (x + bounds.x - handler.getGameCamera().getxOffset()),
			//	(int) (y + bounds.y - handler.getGameCamera().getyOffset()),
			//	bounds.width, bounds.height);
	}
}
