package game.entities;

import java.awt.Graphics;
import java.util.*;

import game.entities.Player.Knight;
import game.entities.Player.Mage;
import game.run.Handler;

public class EntityManager {
	
	private Handler handler;
	private Knight knight;
	private Mage mage;
	private ArrayList<Entity> entities;
	private Comparator<Entity> renderSorter = new Comparator<Entity>() {

		@Override
		public int compare(Entity a, Entity b) {
			if(a.getY()+a.getHeight() < b.getY()+b.getHeight()) {
				return -1;
			}
			return 1;
		}
		
	};
	
	public EntityManager(Handler handler, Knight knight) {
		this.handler=handler;
		this.knight=knight;
		entities = new ArrayList<Entity>();
		addEntity(knight);
	}
	
	public void addEntity(Entity e) {
		entities.add(e);
	}
	
	public void tick() {
		for(int i = 0; i<entities.size(); i++) {
			Entity e=entities.get(i);
			e.tick();
		}
		entities.sort(renderSorter);
	}
	
	public void render(Graphics g) {
		for(Entity e : entities) {
			e.render(g);
		}
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public Knight getKnight() {
		return knight;
	}

	public void setKnight(Knight knight) {
		this.knight = knight;
	}

	public Mage getMage() {
		return mage;
	}

	public void setMage(Mage mage) {
		this.mage = mage;
	}

	public ArrayList<Entity> getEntities() {
		return entities;
	}

	public void setEntities(ArrayList<Entity> entities) {
		this.entities = entities;
	}

}
