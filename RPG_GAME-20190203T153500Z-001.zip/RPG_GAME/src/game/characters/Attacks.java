package game.characters;

public class Attacks {
	public Attacks() {
		
	}

}
