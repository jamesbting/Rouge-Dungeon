package game.run;

public class Run{

	public static void main(String[] args) {
		Game game=new Game("RPG", 1000, 700);
		game.start();

	}
	
	

}
