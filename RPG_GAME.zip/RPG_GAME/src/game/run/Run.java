package game.run;

public class Run{

	public static void main(String[] args) {
		Game game=new Game("Rogue Dungeon", 1000, 700);
		game.start();

	}
	
	

}
