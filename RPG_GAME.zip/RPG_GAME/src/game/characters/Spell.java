package game.characters;
import java.io.*;

public class Spell {
	

}
