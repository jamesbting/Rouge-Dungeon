package game.ui;

public interface ClickListener {
	
	public void onClick();

}
